# -*- coding: utf-8 -*-
import requests
import re
import os
import datetime
url="http://www.freebuf.com/articles"
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101',
'Cookie':'Hm_lvt_cc53db168808048541c6735ce30421f5=1535097676,1535099547,1535099643,1535159901; _ga=GA1.2.1800740087.1524534472; wordpress_logged_in_e7382aacd190d171a15486ff88d472d4=hahahaha123%7C1536045445%7C6659b853f3ede1a2d4068b36fa7902d1; acw_tc=AQAAACb7gw2BhwAAhfEM3+U0UUi/hCrn; 3cb185a485c81b23211eb80b75a406fd=1534690598; Hm_lpvt_cc53db168808048541c6735ce30421f5=1535159948; acw_sc__=5b80ae85efbc69b1707b705e6d52ced54fd5e3c1',}
res = re.compile('<a href="(.*?)"')
res1 = re.compile('<dl>(.*?)</dl>')
res2 = re.compile('<a(.*?)href="(.*?)"(.*?)title="(.*?)">')
res3 = re.compile('<span class="time">(.*?)</span>')
os.remove('file.txt')
get_text = open('file.txt','a')
now_time = datetime.datetime.now()
date = str(now_time).split(' ')[0]
requ = requests.get(url,headers=headers)
file = res1.findall(requ.text.replace('\n',''))
for x in file:
	file1 = res2.findall(x)
	file2 = res3.findall(x)
	# if file2[0].encode('utf-8') != date.decode('utf-8'):
	# 	print 123456
	# 	continue
	y = file1[0]
	get_text.write(y[3].encode('utf-8'))
	get_text.write("		")
	get_text.write(file2[0].encode('utf-8'))
	get_text.write("\n")
	get_text.write(y[1].encode('utf-8'))
	get_text.write("\n"*2)
get_text.close()





